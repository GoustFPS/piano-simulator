# Piano Virtual

<p align="center">
  <img src="./.github/preview.gif" alt="Jogo de um Piano Virtual">
</p>

Esse jogo foi desenvolvido durante o Bootcamp: Potência Tech iFood - Desenvolvimento de Jogos

### Tecnologias Utilizadas

- HTML5 e CSS3:
  - Para a estrutura e aparência do jogo.
- JavaScript:
  - Para a lógica de programação e interatividade.